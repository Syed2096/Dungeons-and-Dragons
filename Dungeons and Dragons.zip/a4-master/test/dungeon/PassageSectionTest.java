package dungeon;

import dnd.models.Exit;
import dnd.models.Monster;
import org.junit.Test;
import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.BeforeClass;

public class PassageSectionTest {

/* set up similar to the sample in PassageTest.java */

    private PassageSection section;

    @Before
    public void setup(){

        section = new PassageSection();

    }

    @Test
    public void testGetDoor() {
        System.out.println("testGetDoor");

        section = new PassageSection("passage ends in Door to a Chamber");
        Door test = section.getDoor();

        if(test != null) {

            assertEquals(true, true);

        } else {

            assertEquals(false, true);
        }

    }

    @Test
    public void testGetMonsterOne() {
        System.out.println("getMonsterOne");

        section = new PassageSection("Wandering Monster (passage continues straight for 10 ft)");
        Monster m = section.getMonster();

        if(m != null) {

            assertEquals(true, true);

        } else {

            assertEquals(false, true);
        }

    }

    @Test
    public void testGetMonsterTwo() {
        System.out.println("getMonsterTwo");

        section = new PassageSection("passage ends in Door to a Chamber");
        Monster m = section.getMonster();

        if(m != null) {

            assertEquals(false, true);

        } else {

            assertEquals(true, true);
        }

    }

    @Test
    public void testGetStairs() {
        System.out.println("getStairs");

        section = new PassageSection("stairs");

        String result = section.getDescription();
        assertTrue(result.contains("stairs"));

    }

    @Test
    public void testGetDescription() {
        System.out.println("getDescription");

        section = new PassageSection("passage ends in Door to a Chamber");

        String result = section.getDescription();
        assertTrue(result.contains("passage ends in Door to a Chamber"));

    }

}
