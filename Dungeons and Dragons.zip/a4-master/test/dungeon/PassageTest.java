package dungeon;

import dnd.models.Exit;
import dnd.models.Monster;
import dnd.models.Stairs;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.BeforeClass;


public class PassageTest {
    //you don't have to use instance variables but it is easier
    // in many cases to have them and use them in each test
    private Passage passage;
    private PassageSection section;
    private PassageSection section2;


    @Before
    public void setup(){

        passage = new Passage();

        section = new PassageSection();
        section2 = new PassageSection("door");

    }

    @Test
    public void testGetDoors() {
        System.out.println("getDoors");

        passage.addPassageSection(section);

        Door test = new Door();
        passage.setDoor(test);

        passage.addPassageSection(section2);

        Door test2 = new Door();
        passage.setDoor(test2);

        int result = passage.getDoors().size();
        int expResult = 2;
        assertEquals(expResult, result);

    }

    @Test
    public void testGetDoor() {
        System.out.println("getDoor");

        Door test = new Door();

        passage.addPassageSection(section);
        passage.setDoor(test);

        ArrayList<Door> doors = passage.getDoors();

        Door result = passage.getDoor(0);
        Door expResult = test;

        assertEquals(expResult, result);
    }

    @Test
    public void testAddMonster() {
        System.out.println("addMonster");
        Monster theMonster = new Monster();

        passage.addPassageSection(section);
        passage.addPassageSection(section2);

        passage.addMonster(theMonster, 1);

        Monster m = passage.getMonster(1);

        assertEquals(theMonster, m);

    }

    @Test
    public void testGetMonster() {
        System.out.println("getMonster");
        Monster theMonster = new Monster();

        passage.addPassageSection(section);
        passage.addPassageSection(section2);

        passage.addMonster(theMonster, 1);

        Monster m = passage.getMonster(1);

        assertEquals(theMonster, m);

    }

    @Test
    public void testAddPassageSection() {
        System.out.println("addPassageSection");

        passage.addPassageSection(section2);

        assertTrue(passage.getDescription().contains("door"));

    }

    @Test
    public void testSetDoor() {
        System.out.println("setDoor");

        Door test = new Door();
        passage.setDoor(test);

        Door door = passage.getDoor(0);

        assertEquals(test, door);

    }

    @Test
    public void testGetDescription() {
        System.out.println("getDescription");

        passage.addPassageSection(section);
        passage.addPassageSection(section2);

        Monster m = new Monster();
        passage.addMonster(m, 1);

        String result = passage.getDescription();

        assertTrue(result.contains(m.getDescription()) && result.contains("door"));

    }

}
