package dungeon;

import dnd.models.Trap;
import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertTrue;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;



public class DoorTest {

    private Door door;

    public DoorTest() {
    }

    @Before
    public void setup(){

        door = new Door();

    }


    @Test
    public void testSetTrappedOne() {
        System.out.println("setTrappedOne");

        door.setArchway(false);
        door.setTrapped(true);

        assertEquals(true, door.isTrapped());

    }

    @Test
    public void testSetTrappedTwo() {
        System.out.println("setTrappedTwo");

        door.setArchway(false);
        door.setTrapped(false);

        assertEquals(false, door.isTrapped());

    }

    @Test
    public void testSetOpenOne() {
        System.out.println("setOpenOne");

        door.setArchway(true);

        door.setOpen(false);

        assertEquals(true, door.isOpen());

    }

    @Test
    public void testSetOpenTwo() {
        System.out.println("setOpenTwo");

        door.setArchway(false);

        door.setOpen(false);

        assertEquals(false, door.isOpen());

    }

    @Test
    public void testSetArchwayOne() {
        System.out.println("setArchwayOne");

        door.setArchway(false);

        assertEquals(false, door.isArchway());

    }

    @Test
    public void testSetArchwayTwo() {
        System.out.println("setArchwayTwo");

        door.setArchway(true);

        assertEquals(true, door.isArchway());

    }

    @Test
    public void testSetArchwayThree() {
        System.out.println("setArchwayThree");

        door.setArchway(true);

        assertEquals(false, door.isTrapped());

    }

    @Test
    public void testIsTrappedOne() {
        System.out.println("isTrappedOne");

        door.setArchway(false);
        door.setTrapped(true);

        assertEquals(true, door.isTrapped());

    }

    @Test
    public void testIsTrappedTwo() {
        System.out.println("isTrappedTwo");

        door.setArchway(false);
        door.setTrapped(false);

        assertEquals(false, door.isTrapped());

    }

    @Test
    public void testIsOpenOne() {
        System.out.println("isOpenOne");

        door.setArchway(false);
        door.setOpen(false);

        assertEquals(false, door.isOpen());

    }

    @Test
    public void testIsOpenTwo() {
        System.out.println("isOpenTwo");

        door.setArchway(false);
        door.setOpen(true);

        assertEquals(true, door.isOpen());

    }

    @Test
    public void testIsArchwayOne() {
        System.out.println("isArchwayOne");

        door.setArchway(false);

        assertEquals(false, door.isArchway());

    }

    @Test
    public void testIsArchwayTwo() {
        System.out.println("isArchwayTwo");

        door.setArchway(true);

        assertEquals(true, door.isArchway());

    }

    @Test
    public void testGetTrapDescription() {
        System.out.println("getTrapDescriptionOne");

        door.setArchway(false);
        door.setTrapped(true, 15);
        String expect = "Arrow trap, 1-3 arrows, 1 in 20 is poisoned.";

        System.out.println("Trap description: " + (door.getTrapDescription()));
        String result = door.getTrapDescription();
        assertTrue(result.contains(expect));

    }

    @Test
    public void testSetSpacesOne() {
        System.out.println("setSpacesOne");
        Chamber test = new Chamber();

        door.setSpaces(test, null);

        ArrayList<Space> result = door.getSpaces();

        assertEquals(test, result.get(0));
    }

    @Test
    public void testSetSpacesTwo() {
        System.out.println("setSpacesTwo");
        Chamber test = new Chamber();
        Passage test2 = new Passage();

        door.setSpaces(test, test2);

        ArrayList<Space> result = door.getSpaces();

        assertEquals(2, result.size());
    }

    @Test
    public void testGetSpaces() {
        System.out.println("getSpaces");

        Chamber test = new Chamber();
        Passage test2 = new Passage();

        door.setSpaces(test, test2);

        ArrayList<Space> result = door.getSpaces();

        assertEquals(2, result.size());

    }

    @Test
    public void testGetDescriptionOne() {
        System.out.println("getDescriptionOne");

        door.setArchway(false);
        door.setTrapped(true, 15);

        String expResult = "trap";
        String result = door.getDescription();
        assertTrue(result.contains(expResult));

    }

    @Test
    public void testGetDescriptionTwo() {
        System.out.println("getDescriptionTwo");

        door.setArchway(true);

        String expResult = "Archway";
        String result = door.getDescription();
        assertTrue(result.contains(expResult));

    }


/* set up similar to the sample in PassageTest.java */

}
