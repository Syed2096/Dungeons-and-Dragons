package dungeon;

import dnd.models.ChamberContents;
import dnd.models.ChamberShape;
import dnd.models.DnDElement;
import dnd.models.Monster;
import dnd.models.Stairs;
import dnd.models.Trap;
import dnd.models.Treasure;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import dnd.die.D20;
import static org.junit.Assert.*;

/**
* @author Ahmed Syed
*/
public class ChamberTest {

    /**
    *Chamber shape object.
    */
    private ChamberShape theShape;

    /**
    *Chamber contents object.
    */
    private ChamberContents theContents;

    /**
    *Monster object.
    */
    private Monster myMonster;

    /**
    *20 sided die object.
    */
    private D20 die = new D20();

    /*
    *Constructor.
    */
    public ChamberTest() {
    }


    @Before
    public void setup(){

        theShape = theShape.selectChamberShape(die.roll());

        theShape.setNumExits();
        theContents = new ChamberContents();
    }

    @Test
    public void testGetShape1()
    {
        System.out.println("setShapeOne");

        Chamber instance = new Chamber();
        instance.setShape(theShape);

        int numberExit = instance.getDoors().size();
        int target = theShape.getNumExits();
        if (target == 0) {
            target++;
        }
        assertEquals(target, numberExit);
    }

    @Test
    public void testGetShape2()
    {
        System.out.println("setShapeTwo");

        Chamber instance = new Chamber();
        instance.setShape(theShape);

        String result = instance.getDescription();
        String target = Integer.toString(theShape.getArea());

        assertTrue(result.contains(target));
    }

    @Test
    public void testGetDoors() {
        System.out.println("getDoors");

        int numberOfExit = theShape.getNumExits();
        if (numberOfExit == 0) {
            numberOfExit++;
        }
        Chamber instance = new Chamber(theShape, theContents);
        int numberOfDoor = instance.getDoors().size();

        assertEquals(numberOfExit, numberOfDoor);

    }

    @Test
    public void testGetMonstersOne() {
        System.out.println("getMonstersOne");
        Chamber instance = new Chamber();
        int m = instance.getMonsters().size();

        instance.addMonster(new Monster());

        int expResult = 1 + m;
        ArrayList<Monster> result = instance.getMonsters();

        assertEquals(expResult, result.size());

    }

    @Test
    public void testGetMonstersTwo() {
        System.out.println("getMonstersTwo");
        Chamber instance = new Chamber();
        int m = instance.getMonsters().size();

        Monster monster = new Monster();
        instance.addMonster(monster);

        int expResult = 1 + m;
        ArrayList<Monster> result = instance.getMonsters();

        assertEquals(monster, result.get(m));

    }

    @Test
    public void testAddTreasureOne() {
        System.out.println("addTreasureOne");

        Chamber instance = new Chamber();
        int t = instance.getTreasureList().size();

        instance.addTreasure(new Treasure());
        int result = instance.getTreasureList().size();

        System.out.println("Treasure list size = " + result);

        int expResult = 1 + t;

        assertEquals(expResult, result);
    }

    @Test
    public void testAddTreasureTwo() {
        System.out.println("addTreasureTwo");

        Chamber instance = new Chamber();
        Treasure test = new Treasure();
        test.setContainer(die.roll());

        instance.addTreasure(new Treasure());
        String result = test.getContainer();
        assertTrue(result.contains(test.getContainer()));

    }

    @Test
    public void testGetTreasureList() {
        System.out.println("getTreasureList");
        Chamber instance = new Chamber();
        int t = instance.getTreasureList().size();

        Treasure expResult = new Treasure();
        instance.addTreasure(expResult);

        ArrayList<Treasure> result = instance.getTreasureList();
        assertEquals(expResult, result.get(t));

    }

    @Test
    public void testGetDescription() {
        System.out.println("getDescription");
        Chamber instance = new Chamber(theShape, theContents);

        String result = instance.getDescription();
        assertTrue(instance.getDescription().contains(theContents.getDescription()));

    }

    @Test
    public void testSetDoor() {
        System.out.println("setDoor");
        Chamber instance = new Chamber();
        int d = instance.getDoors().size();

        Door expResult = new Door();
        instance.setDoor(expResult);

        ArrayList<Door> result = instance.getDoors();

        assertEquals(expResult, result.get(d));

    }

}
