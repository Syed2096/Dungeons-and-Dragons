/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/
package dungeon;

/*Import libraries*/
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.geometry.Pos;

public class AlertBox {

    /**
    * Displays alert with message.
    * @param title title of alert
    * @param message message of alert
    */
    public static void display(String title, String message) {
        Stage window = new Stage();

        //Block events to other windows
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setWidth(300);
        window.setHeight(200);

        Label label = new Label();
        label.setText(message);
        label.getStyleClass().add("description");
        Button closeButton = new Button("Okay");
        closeButton.setOnAction(e -> window.close());
        closeButton.setTranslateY(10);

        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, closeButton);
        layout.setAlignment(Pos.CENTER);

        //Display window and wait for it to be closed before returning
        Scene scene = new Scene(layout);
        scene.getStylesheets().add("/res/theme.css");
        window.setScene(scene);
        window.showAndWait();
    }

}
