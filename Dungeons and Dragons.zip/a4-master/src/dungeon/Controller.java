/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

//Package
package dungeon;

import dnd.models.Treasure;
import dnd.models.Monster;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;

public class Controller {

    /**
    * Level.
    */
    private Level level;

    /**
    * Creates sets level.
    */
    public Controller() {
        level = new Level();
    }

    /**
    * Gets description for label.
    * @param selection space selected to get description of.
    * @return description.
    */
    public String getDescription(String selection) {

        if (selection.contains("Passage")) {

            ArrayList<Passage> passages = level.getPassageList();

            int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));

            for (int i = 0; i < passages.size(); i++) {

                if (num == i + 1) {

                    String description = "-------------------------------Passage-" + (i + 1) + "-------------------------------\n";

                    description += passages.get(i).getDescription();

                    if (description.charAt(description.length() - 1) != '\n') {
                        description += "\n";
                    }

                    description += "-----------------------------------------------------------------------\n";

                    return description;

                }

            }

        }

        ArrayList<Chamber> chambers =  level.getChamberList();

        for (int i = 0; i < chambers.size(); i++) {

            if (selection.contains(String.valueOf(i + 1))) {

                String description = "-------------------------------Chamber-" + (i + 1) + "-------------------------------\n";

                description += chambers.get(i).getChamberDescription();

                if (description.charAt(description.length() - 1) != '\n') {
                    description += "\n";
                }

                description += "-----------------------------------------------------------------------\n";

                return description;

            }

        }

        return "Error getting Description";

    }

    /**
    * Gets door numbers.
    * @param selection space selected.
    * @return number of doors.
    */
    public int getDoorNum(String selection) {

        if (selection.contains("Passage")) {

           ArrayList<Passage> passages = level.getPassageList();
           int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));

           for (int i = 0; i < passages.size(); i++) {

               if (num == i + 1) {

                   ArrayList<Door> doors = passages.get(i).getDoors();
                   return doors.size();

               }

           }

        }

        ArrayList<Chamber> chambers =  level.getChamberList();

        for (int i = 0; i < chambers.size(); i++) {

            if (selection.contains(String.valueOf(i + 1))) {

                ArrayList<Door> doors = chambers.get(i).getDoors();
                return doors.size();

            }

        }

        return -1;

    }

    /**
    * Gets monsters in space.
    * @param selection space selected.
    * @return monsters
    */
    public ArrayList<Monster> getMonsters(String selection) {

        ArrayList<Monster> monsters = new ArrayList<>();

        if (selection.contains("Passage")) {

            ArrayList<Passage> passages = level.getPassageList();
            int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));
            for (int i = 0; i < passages.size(); i++) {

                if (num == i + 1) {

                    if (passages.get(i).getMonster(0) != null) {
                        monsters.add(passages.get(i).getMonster(0));
                    }
                    if (passages.get(i).getMonster(1) != null) {
                       monsters.add(passages.get(i).getMonster(1));
                    }

                    return monsters;

                }

            }

        } else {

            ArrayList<Chamber> chambers = level.getChamberList();

            for (int i = 0; i < chambers.size(); i++) {

                if (selection.contains(String.valueOf(i + 1))) {

                    monsters = chambers.get(i).getMonsters();
                    return monsters;

                }

            }

        }

        return null;

    }

    /**
    * Gets treasures from space.
    * @param selection space selected
    * @return treasures in space
    */
    public ArrayList<Treasure> getTreasures(String selection) {

        ArrayList<Treasure> treasures = new ArrayList<>();

        if (selection.contains("Passage")) {

            ArrayList<Passage> passages = level.getPassageList();
            int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));
            for (int i = 0; i < passages.size(); i++) {

                if (num == i + 1) {

                    if (passages.get(i).getTreasure(0) != null) {
                        treasures.add(passages.get(i).getTreasure(0));
                    }
                    if (passages.get(i).getTreasure(1) != null) {
                        treasures.add(passages.get(i).getTreasure(1));
                    }

                    return treasures;

                }

            }

        } else {

            ArrayList<Chamber> chambers = level.getChamberList();

            for (int i = 0; i < chambers.size(); i++) {

                if (selection.contains(String.valueOf(i + 1))) {

                    treasures = chambers.get(i).getTreasureList();
                    return treasures;

                }

            }

        }

        return null;

    }

    /**
    * Gets number of passages.
    * @return number of passages.
    */
    public int getPassageNum() {

        ArrayList<Passage> passages = this.level.getPassageList();

        return passages.size();

    }

    /**
    * Gets description of door.
    * @param selection selected space.
    * @param doorNum specific door from space.
    * @return door description.
    */
    public String getDoorDescription(String selection, int doorNum) {

        String description = "Error";
        Door door = null;
        ArrayList<Chamber> chambers = level.getChamberList();

        if (selection.contains("Passage")) {

            ArrayList<Passage> passages = level.getPassageList();
            int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));

            for (int i = 0; i < passages.size(); i++) {

                if (num == i + 1) {

                   door = passages.get(i).getDoors().get(doorNum - 1);

                   description = "Door " + doorNum + ": " + door.getDescription();
                   break;

                }

            }

        } else {

            for (int i = 0; i < chambers.size(); i++) {

                if (selection.contains(String.valueOf(i + 1))) {

                    door = chambers.get(i).getDoors().get(doorNum - 1);

                    description = "Door " + doorNum + ": " + door.getDescription();

                    break;

                }

            }

        }

        description += "\nSegment Connections: \t";

        ArrayList<Space> spaces = door.getSpaces();

        for (int j = 0; j < chambers.size(); j++) {

            if (spaces.get(0).equals(chambers.get(j)) || spaces.get(1).equals(chambers.get(j)) || spaces.get(2).equals(chambers.get(j))) {

                description += "Chamber " + (j + 1) + "\t";

            }

        }

        ArrayList<Passage> passages = level.getPassageList();

        for (int i = 0; i < passages.size(); i++) {

            if (spaces.get(0).equals(passages.get(i)) || spaces.get(1).equals(passages.get(i)) || spaces.get(2).equals(passages.get(i))) {

                description += "Passage " + (i + 1) + "\t";

            }

        }

        return description;

    }

    /**
    * Saves level.
    */
    public void saveLevel() {

        AlertBox.display("Saving", "Make sure a file name manually typed in!");

        FileChooser fc = new FileChooser();
        File file = fc.showSaveDialog(null);

        try {

            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file.getAbsolutePath() + ".ser"));
            out.writeObject(level);
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {

        }

    }

    /**
    * Loads level.
    */
    public void loadLevel() {

        AlertBox.display("Help", "Let me know why my files don't load if you can.");

        FileChooser fc = new FileChooser();
        File file = fc.showOpenDialog(null);

        try {

            ObjectInputStream in = new ObjectInputStream(new FileInputStream(file.getAbsolutePath()));
            System.out.println(level.getChamberList().get(0).getChamberDescription());
            level = (Level) in.readObject();
            System.out.println(level.getChamberList().get(0).getChamberDescription());
            in.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {

        }

    }


    /**
    * Creates new level.
    */
    public void newLevel() {

        level = new Level();

    }

    /**
    * Remove item from space.
    * @param selection selected space.
    * @param itemDescription description of item to be removed.
    */
    public void removeSpace(String selection, String itemDescription) {

        if (selection.contains("Passage")) {

            ArrayList<Passage> passages = level.getPassageList();
            int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));

            if (passages.get(num - 1).getMonster(0).getDescription().equalsIgnoreCase(itemDescription)) {

                passages.get(num - 1).thePassage.get(0).monster = null;
                return;

            } else if (passages.get(num - 1).getMonster(1).getDescription().equalsIgnoreCase(itemDescription)) {

                passages.get(num - 1).thePassage.get(1).monster = null;
                return;

            }

            if (passages.get(num - 1).getTreasure(0).getDescription().equalsIgnoreCase(itemDescription)) {

                passages.get(num - 1).thePassage.get(0).treasure = null;
                return;

            } else if (passages.get(num - 1).getTreasure(1).getDescription().equalsIgnoreCase(itemDescription)) {

                passages.get(num - 1).thePassage.get(1).treasure = null;
                return;

            }


        } else {

            ArrayList<Chamber> chambers = level.getChamberList();
            int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));

            ArrayList<Monster> monsters = chambers.get(num - 1).getMonsters();
            ArrayList<Treasure> treasures = chambers.get(num - 1).getTreasureList();

            for (int j = 0; j < monsters.size(); j++) {

            if (monsters.get(j).getDescription().equalsIgnoreCase(itemDescription)) {

                    chambers.get(num - 1).monsterList.remove(j);
                    return;

                }

            }

            for (int j = 0; j < treasures.size(); j++) {

                if (treasures.get(j).getDescription().equalsIgnoreCase(itemDescription)) {

                    chambers.get(num - 1).treasureList.remove(j);
                    return;

                }

            }

        }

    }

    /**
    * Add items to space.
    * @param selection space selected
    * @param itemDescription description of item to be added
    */
    public void addSpace(String selection, String itemDescription) {

        int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));

        if (selection.contains("Passage")) {

            Passage passage = level.getPassageList().get(num - 1);

            for (int i = 1; i <= 100; i++) {

                Monster monster = new Monster();
                monster.setType(i);

                Treasure treasure = new Treasure();
                treasure.chooseTreasure(i);

                Random dice = new Random();
                treasure.setContainer(dice.nextInt(20) + 1);

                if (monster.getDescription().equalsIgnoreCase(itemDescription)) {

                    if (null == passage.getMonster(0)) {

                        passage.addMonster(monster, 0);

                    } else if (null == passage.getMonster(1)) {

                        passage.addMonster(monster, 1);

                    } else {

                        AlertBox.display("Error", "This passage contains a monster\nin each section already!");
                        return;

                    }

                    AlertBox.display("Addition", itemDescription + " has been added\nto " + selection + "!");
                    return;

                } else if (treasure.getDescription().equalsIgnoreCase(itemDescription)) {

                    if (null == passage.getTreasure(0)) {

                        passage.addTreasure(treasure, 0);

                    } else if (null == passage.getTreasure(1)) {

                        passage.addTreasure(treasure, 1);

                    } else {

                        AlertBox.display("Error", "This passage contains treasure in\neach section already!");
                        return;

                    }

                    AlertBox.display("Addition", itemDescription + " has been added\nto " + selection + "!");
                    return;

                }

            }

        } else {

            ArrayList<Chamber> chambers = level.getChamberList();

            for (int i = 1; i <= 100; i++) {

                Monster monster = new Monster();
                monster.setType(i);

                Treasure treasure = new Treasure();
                treasure.chooseTreasure(i);

                Random dice = new Random();
                treasure.setContainer(dice.nextInt(20) + 1);

                if (monster.getDescription().equalsIgnoreCase(itemDescription)) {

                    chambers.get(num - 1).monsterList.add(monster);
                    AlertBox.display("Addition", itemDescription + " has been added\nto " + selection + "!");
                    return;

                } else if (treasure.getDescription().equalsIgnoreCase(itemDescription)) {

                    chambers.get(num - 1).treasureList.add(treasure);
                    AlertBox.display("Addition", itemDescription + " has been added\nto " + selection + "!");
                    return;

                }

            }


        }

    }

    /**
    * Generates visual for selected space.
    * @param selection selected space
    */
    public void getImage(String selection) {

        //floor = 0;
      //door = 1;
      //monster = 2;
      //treasure = 3;
      int[][] map = new int[10][10];
      int num = Integer.parseInt(selection.replaceAll("[^0-9]", ""));
      int numMonsters = 0;
      int numDoors = 0;
      int numTreasures = 0;

      if (selection.contains("Passage")) {

          Passage passage = level.getPassageList().get(num - 1);
          numDoors = passage.getDoors().size();

          if (passage.thePassage.get(0).monster != null) {
              numMonsters++;
          }
          if (passage.thePassage.get(1).monster != null) {
              numMonsters++;
          }
          if (passage.thePassage.get(0).treasure != null) {
              numTreasures++;
          }
          if (passage.thePassage.get(1).treasure != null) {
              numTreasures++;
          }

      } else {

          Chamber chamber = level.getChamberList().get(num - 1);
          numDoors = chamber.getDoors().size();
          numMonsters = chamber.getMonsters().size();
          numTreasures = chamber.getTreasureList().size();

      }

      Stage visual = new Stage();
      visual.setTitle("View");
      Label[][] view = new Label[10][10];

      GridPane layout = new GridPane();
      for (int i = 0; i < 10; i++) {

          for (int j = 0; j < 10; j++) {

              try {

                  if ((i == 0 || j == 0 || i == 9 || j == 9) && numDoors > 0 && i % 4 == 0 && j % 4 == 0) {

                      view[i][j] = createImage("/res/door.jpg");
                      map[i][j] = 1;
                      numDoors--;

                  } else if (numTreasures > 0 && i != 0 && j != 0 && i != 9 && j != 9 && map[i][j - 1] == 0 && map[i - 1][j] == 0 && map[i - 1][j - 1] == 0 && map[i - 1][j + 1] == 0) {

                      view[i][j] = createImage("/res/treasure.jpg");
                      map[i][j] = 3;
                      numTreasures--;

                  } else if (numMonsters > 0 && i != 0 && j != 0 && i != 9 && j != 9 && map[i][j - 1] == 0 && map[i - 1][j] == 0 && map[i - 1][j - 1] == 0 && map[i - 1][j + 1] == 0) {

                      view[i][j] = createImage("/res/monster.jpg");
                      map[i][j] = 2;
                      numMonsters--;

                  } else {

                      //Default
                      map[i][j] = 0;
                      view[i][j] = createImage("/res/background.jpg");

                  }

              } catch (ArrayIndexOutOfBoundsException e) {

              }

              layout.add(view[i][j], i, j);

          }

      }

      layout.setScaleX(2);
      layout.setScaleY(2);
      layout.setAlignment(Pos.CENTER);

      Scene scene = new Scene(layout, 500, 500);
      visual.setScene(scene);
      visual.show();

    }

    /**
    * Creates image using jpg.
    * @param directory directory of file
    * @return returns image
    */
    public Label createImage(String directory) {

        Label image = new Label();

        ImageView pic = new ImageView(directory);
        pic.setFitHeight(25);
        pic.setFitWidth(25);
        image.setGraphic(pic);

        return image;

    }


}
