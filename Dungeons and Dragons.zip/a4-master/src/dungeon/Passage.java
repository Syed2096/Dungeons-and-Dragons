/*
*Name: Ahmed Syed
*Student ID: 1051777
*/

/*Import Package*/
package dungeon;

/*Import Libraries*/
import dnd.models.Monster;
import dnd.models.Treasure;
import java.util.ArrayList;

public class Passage extends Space implements java.io.Serializable {
    //these instance variables are suggestions only
    //you can change them if you wish.

    /**
    *Create passage using a list of passage sections.
    */
    public ArrayList<PassageSection> thePassage = new ArrayList<>();

    /**
    *Create a list of doors for the passages.
    */
    private ArrayList<Door> doorList = new ArrayList<>();

    /**
    *Return list of doors.
    *@return ArrayList of doors
    */
    public ArrayList<Door> getDoors() {
        //gets all of the doors in the entire passage

        return doorList;

    }

    /**
    *Returns door in passage section.
    *@param i passage section
    *@return the door in section or null if none exists
    */
    public Door getDoor(int i) {
        //returns the door in section 'i'. If there is no door, returns null

        if (i >= doorList.size()) {

            return null;

        }

        return doorList.get(i);

    }

    /**
    *Adds monster to passage section.
    *@param theMonster monster to be added
    *@param i the passage section
    */
    public void addMonster(Monster theMonster, int i) {
        // adds a monster to section 'i' of the passage

        if (null == (this.thePassage.get(i)).getMonster()) {

            (this.thePassage.get(i)).addMonster(theMonster);

        }

    }

    /**
     *Adds treasure to passage section.
     *@param theTreasure monster to be added
     *@param i the passage section
     */
    public void addTreasure(Treasure theTreasure, int i) {
        // adds a monster to section 'i' of the passage

        if (null == (this.thePassage.get(i)).getTreasure()) {

            (this.thePassage.get(i)).addTreasure(theTreasure);

        }

    }

    /**
    *Returns monster in passage section.
    *@param i passage section
    *@return the monster
    */
    public Monster getMonster(int i) {
        //returns Monster door in section 'i'. If there is no Monster, returns null

        return (this.thePassage.get(i)).getMonster();

    }

    /**
     *Returns treasure in passage section.
     *@param i passage section
     *@return the treasure
     */
    public Treasure getTreasure(int i) {
        //returns Monster door in section 'i'. If there is no Monster, returns null

        return (this.thePassage.get(i)).getTreasure();

    }

    /**
    *Adds passage section to overall passage.
    *@param toAdd section to add
    */
    public void addPassageSection(PassageSection toAdd) {
        //adds the passage section to the passageway
        this.thePassage.add(toAdd);

    }

    /**
    *Adds door to passage.
    *@param newDoor door to add
    */
    @Override
    public void setDoor(Door newDoor) {
        //should add a door connection to the current Passage Section
        newDoor.setSpace(this);
        this.doorList.add(newDoor);

    }

    /**
    *Gets description of passage.
    *@return string of description
    */
    @Override
    public String getDescription() {

        String description = "";

        for (PassageSection passage: thePassage) {

            description += passage.getDescription();

            if (!thePassage.get(thePassage.size() - 1).equals(passage)) {
                description += "\n";
            }

        }

        return description;

    }

}
