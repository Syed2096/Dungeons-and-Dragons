/*
Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Package*/
package dungeon;

public class Launcher {

    /**
    *Main method to launch program.
    *@param args argument
    */
    public static void main(String[] args) {
        Main.main(args);
    }
}
