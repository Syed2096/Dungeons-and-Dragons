/*
*Name: Ahmed asyed12
*Student ID: 1051777
*/

/*Import Package*/
package dungeon;

/*Import Libraries*/
import dnd.models.ChamberContents;
import dnd.models.ChamberShape;
import dnd.models.Monster;
import dnd.models.Treasure;
import dnd.models.Stairs;
import dnd.models.Exit;
import dnd.models.Trap;
import dnd.die.D20;
import dnd.die.Percentile;
import java.util.ArrayList;

public class Chamber extends Space implements java.io.Serializable {

    /**
    *Create instance variable for chamber contents.
    */
    private ChamberContents myContents;
    /**
    *Create instance variable for chamber shape.
    */
    private ChamberShape mySize;
    /**
    *Create list of doors.
    */
    private ArrayList<Door> doorList;
    /**
    *Create list of monsters.
    */
    public ArrayList<Monster> monsterList;
    /**
    *Create list of treasure.
    */
    public ArrayList<Treasure> treasureList;
    /**
    *Stairs.
    */
    private Stairs gameStairs;
    /**
    * trap.
    */
    private Trap gameTrap;
    /**
    *Create a die for 1-20 rolls.
    */
    private D20 die = new D20();
    /**
    *Create a die for 1-100 rolls.
    */
    private Percentile die2 = new Percentile();
    /**
    *Create chamber string.
    */
    private String chamberDescription;

    /**
    *Constructor.
    */
    public Chamber() {

        myContents = new ChamberContents();
        mySize = mySize.selectChamberShape(die.roll());

        this.doorList = new ArrayList<Door>();
        this.monsterList = new ArrayList<Monster>();
        this.treasureList = new ArrayList<Treasure>();

        mySize.setNumExits(die.roll());

        while (mySize.getNumExits() == 0) {

            mySize.setNumExits();

        }

        myContents.chooseContents(die.roll());

        this.setDescription();

    }

    /**
    *Constructor.
    *@param theShape chamber characteristics
    *@param theContents chamber contents
    */
    public Chamber(ChamberShape theShape, ChamberContents theContents) {

    this.mySize = theShape;
    this.myContents = theContents;

    this.doorList = new ArrayList<Door>();
    this.monsterList = new ArrayList<Monster>();
    this.treasureList = new ArrayList<Treasure>();

    this.setDescription();

    }

    /**
    *Set shape of chambers.
    *@param theShape chamber characteristics
    */
    public void setShape(ChamberShape theShape) {

    this.mySize = theShape;

    this.doorList = new ArrayList<>();

    this.setDescription();

    }

    /**
    *Return doors in chamber.
    *@return list of doors
    */
    public ArrayList<Door> getDoors() {

    return this.doorList;

    }

    /**
    *Add monster to chamber.
    *@param theMonster the monster object to add
    */
    public void addMonster(Monster theMonster) {

        theMonster.setType(die2.roll());

        monsterList.add(theMonster);

    }

    /**
    *Get monsters from chamber.
    *@return list of monsters
    */
    public ArrayList<Monster> getMonsters() {

        return this.monsterList;

    }

    /**
    *Add treasure to chamber.
    *@param theTreasure the treasure to add
    */
    public void addTreasure(Treasure theTreasure) {

        theTreasure.chooseTreasure(die2.roll());
        theTreasure.setContainer(die.roll());

        treasureList.add(theTreasure);

    }

    /**
    *Return treasure from chamber.
    *@return treasure list
    */
    public ArrayList<Treasure> getTreasureList() {

        return this.treasureList;

    }

    /**
    *Set description.
    */
    private void setDescription() {

        this.chamberDescription = this.generateChamberShape() + this.generateChamberContents();

    }

    /**
    *Return description.
    *@return string of description
    */
    @Override
    public String getDescription() {

        return chamberDescription;

    }

    /**
    *Set door to chamber.
    *@param newDoor door to add
    */
    @Override
    public void setDoor(Door newDoor) {
    //should add a door connection to this room

        this.doorList.add(newDoor);

    }

    /**
    *Generate treasure for chamber.
    *@return treasure description
    */
    private String generateTreasure() {

        String description;

        Treasure gameTreasure = new Treasure();

        this.addTreasure(gameTreasure);

        description = "\nTreasure Generated: " + gameTreasure.getDescription() + "\nTreasure Container: " + gameTreasure.getContainer() + "\n";

        try {

            description = description.concat("Treasure Protection: Guarded by " + gameTreasure.getProtection() + "\n");

        } catch (Exception NotProtectedException) {

        }

        return description;

    }

    /**
    *Generate monster for chamber.
    *@return monster description
    */
    private String generateMonster() {

        String description;

        Monster gameMonster = new Monster();

        this.addMonster(gameMonster);

        description = "\nMonster Generated: " + gameMonster.getDescription() + "\t\tQuantity : (" + gameMonster.getMinNum() + " - " + gameMonster.getMaxNum() + ")\n";

        return description;

    }

    /**
    *Generate stairs for chamber.
    *@return stairs description
    */
    private String generateStairs() {

        String description;

        gameStairs = new Stairs();

        gameStairs.setType(die.roll());

        description = "\nStairs Description: " + gameStairs.getDescription() + "\n";

        return description;

    }

    /**
    *Generate trap for chamber.
    *@return trap description
    */
    private String generateTraps() {

        String description;

        gameTrap = new Trap();

        gameTrap.chooseTrap(die.roll());

        description = "\nTrap Description: " + gameTrap.getDescription() + "\n";

        return description;

    }

    /**
    *Generate chamber shape.
    *@return chamber characteristics
    */
    private String generateChamberShape() {

        String description;
        int i;

        description = "Shape of chamber: " + this.mySize.getShape() + "\t\tArea: " + this.mySize.getArea() + "m^2\n";

        try {

            description = description.concat("Length: " + this.mySize.getLength() + "m\t\tWidth: " + this.mySize.getWidth() + "m\n");

        } catch (Exception UnusualShapeException) {

        }

        description = description.concat("Number of Doors: " + this.mySize.getNumExits() + "\n\n");

        setDoors();

        return description;

    }

    /**
    *Set doors.
    */
    private void setDoors() {

        for (int i = 0; i < this.mySize.getNumExits(); i++) {

            Exit exit = new Exit();
            Door door = new Door(exit);

            door.setSpace(this);

            this.setDoor(door);

        }

    }

    /**
    *Generate chamber contents and return its description.
    *@return chamber contents description
    */
    private String generateChamberContents() {

        String description = "---------------------------------------------Chamber-Contents--------------------------------------------\n" + "Description: " + myContents.getDescription() + "\n";

        description = contentDescription(description);

        description = description.concat("\n---------------------------------------------------------------------------------------------------------\n");

        return description;

    }

    /**
    *Add onto contents description.
    *@param description current description.
    *@return chamber contents like monsters, stairs, etc
    */
    private String contentDescription(String description) {

        if (description.indexOf("monster and treasure") != -1) {

           this.generateMonster();
            this.generateTreasure();

        } else if (description.indexOf("treasure") != -1) {

           this.generateTreasure();


        } else if (description.indexOf("monster") != -1) {

            this.generateMonster();

        } else if (description.indexOf("stairs") != -1) {

            description = description.concat(this.generateStairs());

        } else if (description.indexOf("trap") != -1) {

            description = description.concat(this.generateTraps());

        }

        return description;

    }

    /**
     * Chamber description method for GUI.
     * @return description
     */
    public String getChamberDescription() {

        String description = "Shape of chamber: " + this.mySize.getShape() + "\t\tArea: " + this.mySize.getArea() + "m^2\n";
        try {

            description += "Length: " + this.mySize.getLength() + "m\t\tWidth: " + this.mySize.getWidth() + "m\n";

        } catch (Exception UnusualShapeException) {

        }

        description += "Number of Doors: " + this.mySize.getNumExits() + "\n\n";

        description += "--------------------Contents-----------------\n";

        for (int i = 0; i < monsterList.size(); i++) {

            description +=  "Monster " + (i + 1) + ": " + monsterList.get(i).getDescription() + " ---- Quantity (" + monsterList.get(i).getMinNum() + " - " + monsterList.get(i).getMaxNum() + ")\n";

        }

        for (int i = 0; i < treasureList.size(); i++) {

            description += "\nTreasure " + (i + 1) + ": " + treasureList.get(i).getDescription() + "\nTreasure Container: " + treasureList.get(i).getContainer() + "\n";

            try {

                description += "Treasure Protection: Guarded by " + treasureList.get(i).getProtection() + "\n";

            } catch (Exception NotProtectedException) {

            }

        }

        if (gameStairs != null) {
            description += "Stairs: " + gameStairs.getDescription();
        }
        if (gameTrap != null) {

            description += "Trap: " + gameTrap.getDescription();
        }

        return description;

    }

}
