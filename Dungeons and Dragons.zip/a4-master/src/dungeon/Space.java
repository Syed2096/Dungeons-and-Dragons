/*
*Name: Ahmed Syed
*Student ID: 1051777
*/

/*Import package*/
package dungeon;

public abstract class Space {

    /**
    *Get description for space.
    *@return string of description
    */
    public abstract  String getDescription();

    /**
    *Set door for space.
    *@param theDoor the door to set
    */
    public abstract void setDoor(Door theDoor);

}
