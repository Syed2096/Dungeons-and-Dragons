/*
*Name: Ahmed Syed
*Student ID: 1051777
*/

/*Import Package*/
package dungeon;

/*Import Libraries*/
import dnd.models.Exit;
import dnd.models.Trap;
import java.util.ArrayList;
import dnd.die.D20;
import dnd.die.D10;
import dnd.die.D6;

public class Door implements java.io.Serializable {

    /**
    *Create list for spaces connected to door.
    */
    private ArrayList<Space> spaceList;

    /**
    *Create trap for door.
    */
    private Trap gameTrap = new Trap();

    /**
    *Create 20 sided dice.
    */
    private D20 die = new D20();

    /**
    *Create 10 sided dice.
    */
    private D10 die2 = new D10();

    /**
    *Create 6 sided sice.
    */
    private D6 die3 = new D6();

    /**
    *Variable for trapped.
    */
    private boolean isTrapped;

    /**
    *Create variable for open.
    */
    private boolean isOpen;

    /**
    *Create variable for archway.
    */
    private boolean isArchway;

    /**
    *Create variable for isDoor, this was used to determine if the door was being used just for direction.
    */
    private boolean isDoor;

    /**
    *Create variable for direction, this was used for passages at one point.
    */
    private String direction;

    /**
    *Door Constructor.
    */
    public Door() {

        this.isTrapped = false;
        this.isArchway = false;
        this.isOpen = true;
        this.isDoor = true;

        trappedChance();

        openChance();

        archwayChance();

        this.spaceList = new ArrayList<Space>();

        //needs to set defaults
    }

    /**
    *Do roll for trapped.
    */
    private void trappedChance() {

        if (die.roll() == 1) {

            this.isTrapped = true;
            this.gameTrap.chooseTrap(die.roll());

        }

    }

    /**
    *Do roll for open.
    */
    private void openChance() {

        if (die3.roll() == 1) {

            this.isOpen = false;

        }

    }

    /**
    *Do roll for archway.
    */
    private void archwayChance() {

        if (die2.roll() == 1) {

            this.isArchway = true;
            this.isTrapped = false;
            this.isOpen = true;

        }

    }

    /**
    *This sets up the door based on an exit.
    *@param theExit Exit for chamber given as parameter
    */
    public Door(Exit theExit) {
        //sets up the door based on the Exit from the tables

        this.isTrapped = false;
        this.isArchway = false;
        this.isOpen = true;
        this.isDoor = true;

        trappedChance();

        openChance();

        archwayChance();

        this.spaceList = new ArrayList<Space>();

        this.direction = theExit.getLocation();

    }

    /**
    *This method sets and generates a trap if needed.
    *@param flag this is the variable used to set the trap
    *@param roll this is the variable used to set the trap from the table
    */
    public void setTrapped(boolean flag, int... roll) {
        // true == trapped.  Trap must be rolled if no integer is given

        this.isTrapped = flag;

        if (flag) {

            if (roll.length < 1) {

                this.gameTrap.chooseTrap(die.roll());

            } else {

                this.gameTrap.chooseTrap(roll[0]);

            }

        }

    }

    /**
    *Sets the characteristic of open or not.
    *@param flag Used to set open characteristic
    */
    public void setOpen(boolean flag) {
        //true == open
        if (!this.isArchway) {

            this.isOpen = flag;

        }

    }

    /**
    *Sets the characteristic of is a door or not.
    *@param flag Used to set characteristic
    */
    public void setIsDoor(boolean flag) {

        this.isDoor = flag;

    }

    /**
    *Sets the direction of door.
    *@param addDirection Used to set direction
    */
    public void setDirection(String addDirection) {

        this.direction = addDirection;

    }

    /**
    *Gets the direction of door.
    *@return direction
    */
    public String getDirection() {

        return this.direction;

    }

    /**
    *Sets the doorway to archway or to regular door.
    *@param flag Used to set characteristic
    */
    public void setArchway(boolean flag) {
        //true == is archway
        this.isArchway = flag;

        if (flag) {

            this.isTrapped = false;
            this.isOpen = true;

        }

    }

    /**
    *Returns characteristic.
    *@return characteristic
    */
    public boolean isTrapped() {

        return this.isTrapped;

    }

    /**
    *Returns characteristic.
    *@return characteristic
    */
    public boolean isOpen() {

        return this.isOpen;

    }

    /**
    *Returns characteristic.
    *@return characteristic
    */
    public boolean isArchway() {

        return this.isArchway;

    }

    /**
    *Returns trap description.
    *@return trap description
    */
    public String getTrapDescription() {

        if (this.isTrapped) {

            return this.gameTrap.getDescription();

        }

        return null;

    }

    /**
    *Returns spaces connected to door.
    *@return ArrayList of spaces
    */
    public ArrayList<Space> getSpaces() {
        //returns the two spaces that are connected by the door
        return spaceList;

    }

    /**
    *Sets the spaces to this door.
    *@param spaceOne first connection
    *@param spaceTwo second connection
    */
    public void setSpaces(Space spaceOne, Space spaceTwo) {
        //identifies the two spaces with the door
        // this method should also call the addDoor method from Space

        spaceList.add(spaceOne);
        spaceList.add(spaceTwo);

    }

    /**
    *Sets the spaces to this door.
    *@param spaceOne first connection
    */
    public void setSpace(Space spaceOne) {
        //identifies the two spaces with the door
        // this method should also call the addDoor method from Space

        spaceList.add(spaceOne);

    }

    /**
    *Returns description of door.
    *@return string of description
    */
    public String getDescription() {

        String description = "";

        description = openDescription(description);

        description = archwayDescription(description);

        description = trappedDescription(description);

        return description;

    }

    /**
    *Detailed description of door.
    *@param description current description.
    *@return description modified
    */
    private String openDescription(String description) {

        if (this.isOpen) {

            description += "The door is open, ";

        } else {

            description += "The door is closed, ";

        }

        return description;

    }

    /**
    *Detailed description of door.
    *@param description current description.
    *@return description modified
    */
    private String archwayDescription(String description) {

        if (this.isArchway) {

            description += "it's an Archway, ";

        } else {

            description += "it's not an Archway, ";

        }

        return description;

    }

    /**
    *Detailed description of door.
    *@param description current description.
    *@return description modified
    */
    private String trappedDescription(String description) {

        if (this.isTrapped) {

            description += "and it contains a trap.\nTrap: " + gameTrap.getDescription();

        } else {

            description += "and it doesn't contain any traps.\n";

        }

        return description;

    }

}
