/*
*Name: Ahmed Syed
*Student ID: 1051777
*/

/*Import package*/
package dungeon;

/*Import Libraries*/
import dnd.models.Monster;
import dnd.models.Stairs;
import dnd.die.D20;
import dnd.die.Percentile;
import dnd.models.Treasure;

/* Represents a 10 ft section of passageway */

public class PassageSection {

    /**
    *Monster for passage section.
    */
    public Monster monster;

    /**
     * Treasure for passage section.
     */
    public Treasure treasure;

    /**
    *Stairs for passage section.
    */
    private Stairs stairs;

    /**
    *Door for passage section.
    */
    private Door door;

    /**
    *Die for rolls of 1 - 20.
    */
    private D20 die = new D20();

    /**
    *Die for rolls of 1 - 100.
    */
    private Percentile die2 = new Percentile();

    /**
    *Dead end boolean variable.
    */
    private boolean isDeadEnd;

    /**
    *Passage section description.
    */
    private String description;

    /**
     * Initial description.
     */
    private String initial;

    /**
    *Constructor.
    */
    public PassageSection() {
        //sets up the 10 foot section with default settings
        initialSet();

    }

    /**
    *Set initial variables.
    */
    private void initialSet() {

        this.isDeadEnd = false;
        this.door = null;
        this.monster = null;
        this.treasure = null;
        this.stairs = null;

    }

    /**
    *Constructor with description.
    *@param descriptionInitial the description of the section
    */
    public PassageSection(String descriptionInitial) {
        //sets up a specific passage based on the values sent in from
        //modified table 1
        initialSet();

        this.initial = descriptionInitial;
        this.description = descriptionInitial;

        String[] check = description.split(" ");

        for (int i = 0; i < check.length; i++) {

            if (check[i].equalsIgnoreCase("dead")) {

                this.isDeadEnd = true;
                break;

            }
            if (check[i].equalsIgnoreCase("monster")) {

                generateMonster();
                break;

            }
            if (check[i].equalsIgnoreCase("(door)") || check[i].equalsIgnoreCase("door") || check[i].equalsIgnoreCase("left") || check[i].equalsIgnoreCase("right")) {

                generateDoor();

                for (int j = 0; j < check.length; j++) {

                    this.door.setDirection(check[j]);

                }

            }
            if (check[i].equalsIgnoreCase("stairs")) {

                generateStairs();

            }

        }

    }

    /**
    *Sets stairs to true.
    */
    private void generateStairs() {

        this.stairs = new Stairs();
        this.stairs.setType(die.roll());

    }

    /**
    *Creates monster for section.
    */
    public void generateMonster() {

        this.monster = new Monster();
        this.monster.setType(die2.roll());

    }

    /**
    *Generates door for section.
    */
    public void generateDoor() {

        this.door = new Door();

    }

    /**
    *Returns door in section.
    *@return door in section.
    */
    public Door getDoor() {
        //returns the door that is in the passage section, if there is one
        return this.door;

    }

    /**
    *Returns monster in section.
    *@return monster in section.
    */
    public Monster getMonster() {
        //returns the monster that is in the passage section, if there is one
        return this.monster;

    }

    /**
     *Returns treasure in section.
     *@return treasure in section.
     */
    public Treasure getTreasure() {
        //returns the monster that is in the passage section, if there is one
        return this.treasure;

    }

    /**
    *Returns description of section.
    *@return string of description
    */
    public String getDescription() {

        this.description = initial + "\n";

        if (this.monster != null) {

            this.description += "This passage contains a monster: " + this.monster.getDescription() + "\tQuantity: (" + this.monster.getMinNum() + "-" + this.monster.getMaxNum() + ")\n";

        } else if (initial.contains("Monster") && this.monster == null) {

            this.description += "Monster removed!";

        }

        if (this.treasure != null) {

            description += "Treasure: " + treasure.getDescription() + "\nTreasure Container: " + treasure.getContainer() + "\n";

            try {

                description += "Treasure Protection: Guarded by " + treasure.getProtection() + "\n";

            } catch (Exception NotProtectedException) {

            }

        }

         /* else if (this.door != null) {

            this.description += this.door.getDescription();

        } */

        if (this.stairs != null) {

            this.description += this.stairs.getDescription();

        }

        return this.description;

    }

    /**
    *Adds monster to section.
    *@param theMonster monster to add
    */
    public void addMonster(Monster theMonster) {

        this.monster = theMonster;

    }

    /**
     *Adds treasure to section.
     *@param theTreasure treasure to add
     */
    public void addTreasure(Treasure theTreasure) {

        this.treasure = theTreasure;

    }

    /**
    *Adds door to section.
    *@param newDoor door to add
    */
    public void addDoor(Door newDoor) {

        this.door = newDoor;

    }

}
