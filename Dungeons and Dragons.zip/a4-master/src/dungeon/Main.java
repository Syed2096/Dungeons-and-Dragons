/*
Name:Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca
*/

/*Package*/
package dungeon;

/*Include imports*/
import dnd.models.Monster;
import dnd.models.Treasure;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.collections.ObservableList;
import java.util.ArrayList;

public class Main extends Application {

    /**
    * Controller object.
    */
    private Controller controller = new Controller();

    /**
    *Main menu.
    */
    private Stage main;

    /**
    *window.
    */
    private Stage window;

    /**
    *Spaces.
    */
    private ListView<String> spaces;

    /**
    *Description label.
    */
    private Label label;

    /**
    *Description.
    */
    private String description = "Select a chamber or passage";

    /**
    * Launches program.
    * @param args used to launch program
    */
    public static void main(String[] args) {
        launch(args);
    }

    /**
    * Starts with main menu.
    * @param primaryStage start window.
    * @throws Exception default.
    */
    @Override
    public void start(Stage primaryStage) throws Exception {

        main = primaryStage;
        primaryStage.setTitle("Dungeons and Dragons Level Viewer");

        //Label
        label = new Label(description);
        label.getStyleClass().add("description");

        Label selectSpace = new Label("Select a chamber or Passage");
        selectSpace.getStyleClass().add("description");

        Label selectDoor = new Label("Select a door");
        selectDoor.getStyleClass().add("description");

        //Spaces
        spaces = new ListView<>();
        spaces.setMaxWidth(120);
        spaces.setMaxHeight(300);
        ObservableList<String> space = spaces.getSelectionModel().getSelectedItems();
        updateTable();

        //Edit button
        Button edit = new Button();
        edit.setText("Edit");
        edit.setOnAction(e -> {


                try {
                    editMenu(space.get(0));
                } catch (IndexOutOfBoundsException i) {

                    AlertBox.display("Edit Error", "Select a chamber or passage first!");

                }

        });

        //generate view button
        Button view = new Button();
        view.setText("Generate Visual");
        view.setOnAction(e ->  {

            try {

                space.get(0);
                AlertBox.display("Loading", "This may take a bit due\nto nomachine");
                controller.getImage(space.get(0));


            } catch (IndexOutOfBoundsException u) {

                AlertBox.display("Error", "Select a chamber or passage to display!");

            }

        });

        //new level
        Button newLevel = new Button();
        newLevel.setText("Generate New Level");
        newLevel.setTranslateY(265);
        newLevel.setTranslateX(-10);
        newLevel.setOnAction(e -> {

            controller.newLevel();
            description = "Select a chamber or passage";
            label.setText(description);
            updateTable();

        });

        //Doors
        ComboBox<Integer> doorList = new ComboBox<>();
        spaces.getSelectionModel().selectedItemProperty().addListener(e -> {

            if (space.size() > 0) {

                int numDoors = controller.getDoorNum(space.get(0));

                doorList.getItems().clear();
                for (int i = 0; i < numDoors; i++) {

                    doorList.getItems().add((i + 1));

                }

                description = controller.getDescription(space.get(0));
                label.setText(description);

            }

        });

        doorList.setOnAction(e -> {

            if (space.size() > 0 && doorList.getValue() != null) {

                description = controller.getDescription(space.get(0));
                description += controller.getDoorDescription(space.get(0), doorList.getValue());
                label.setText(description);

            }

        });

        //Menu
        MenuItem save = new MenuItem("Save");
        save.setOnAction(e -> controller.saveLevel());

        MenuItem load = new MenuItem("Load");
        load.setOnAction(e ->  {

            controller.loadLevel();
            description = "Select a chamber or passage";
            label.setText(description);
            updateTable();

        });

        Menu fileMenu = new Menu("File");
        fileMenu.getItems().addAll(save, load);

        MenuBar menuBar = new MenuBar();
        menuBar.getStyleClass().addAll("file");
        menuBar.getMenus().add(fileMenu);

        //Left Layout
        VBox leftLayout = new VBox();
        leftLayout.setPadding(new Insets(10, 10, 10, 10));
        leftLayout.setSpacing(10);
        leftLayout.setAlignment(Pos.TOP_CENTER);
        leftLayout.getChildren().addAll(selectSpace, spaces, edit);

        VBox rightLayout = new VBox();
        rightLayout.setPadding(new Insets(10, 10, 10, 10));
        rightLayout.setSpacing(10);
        rightLayout.setAlignment(Pos.TOP_CENTER);
        rightLayout.getChildren().addAll(selectDoor, doorList, newLevel);

        VBox center = new VBox();
        center.setPadding(new Insets(10, 10, 10, 10));
        center.setSpacing(10);
        center.setAlignment(Pos.CENTER);
        center.getChildren().addAll(label, view);

        BorderPane layout = new BorderPane();
        layout.setLeft(leftLayout);
        layout.setRight(rightLayout);
        layout.setCenter(center);
        layout.setTop(menuBar);

        Scene scene = new Scene(layout, 850, 400);
        scene.getStylesheets().add("/res/theme.css");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    /**
    * Edit menu.
    * @param selection used to determine which space was chosen.
    */
    public void editMenu(String selection) {

        Label info = new Label("Edit Menu");
        info.getStyleClass().add("description");

        window = new Stage();
        window.setTitle("Edit Menu");
        window.initModality(Modality.APPLICATION_MODAL);

        ListView<String> options = new ListView<>();
        options.setMaxWidth(250);
        options.setMaxHeight(400);
        ArrayList<Monster> monsters = controller.getMonsters(selection);
        if (monsters != null) {
            for (int i = 0; i < monsters.size(); i++) {
                try {
                    options.getItems().add(monsters.get(i).getDescription());
                } catch (NullPointerException e) {

                }
            }
        }

        ArrayList<Treasure> treasures = controller.getTreasures(selection);
        if (treasures != null) {
            for (int i = 0; i < treasures.size(); i++) {
               try {
                   options.getItems().add(treasures.get(i).getDescription());
               } catch (NullPointerException e) {

               }
            }
        }

        Button add = new Button();
        add.setText("Add");
        add.setOnAction(e -> {

           addMenu(selection);

        });

        Button remove = new Button();
        remove.setText("Remove");
        remove.setOnAction(e -> {

         if (options.getSelectionModel().getSelectedItem() != null) {

             String itemDescription = options.getSelectionModel().getSelectedItem();
             controller.removeSpace(selection, itemDescription);
             description = "Changes Made to " + spaces.getSelectionModel().getSelectedItem();
             label.setText(description);
             AlertBox.display("Removal", itemDescription + " has been removed\nfrom " + spaces.getSelectionModel().getSelectedItem() + "!");
             window.close();
             updateTable();

         } else {

             AlertBox.display("Error", "Select something to remove!");

         }

        });

        HBox bottom = new HBox();
        bottom.getChildren().addAll(add, remove);
        bottom.setSpacing(20);
        bottom.setAlignment(Pos.CENTER);

        VBox layout = new VBox(0);
        layout.getChildren().addAll(info, options, bottom);
        layout.setSpacing(20);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(10, 10, 10, 10));

        Scene editMenu = new Scene(layout, 245, 300);
        window.setScene(editMenu);
        editMenu.getStylesheets().add("/res/theme.css");
        window.showAndWait();

    }

    /**
    * Updates space list.
    */
    public void updateTable() {

        spaces.getItems().clear();
        for (int i = 0; i < 5; i++) {

            spaces.getItems().add("Chamber " + (i + 1));

        }

        for (int i = 0; i < controller.getPassageNum(); i++) {

            spaces.getItems().add("Passage " + (i + 1));

        }

    }

    /**
    * Add menu.
    * @param selection which space is selected.
    */
    public void addMenu(String selection) {

        Stage addMenu = new Stage();
        addMenu.setTitle("Add Menu");
        addMenu.initModality(Modality.APPLICATION_MODAL);

        Label monster = new Label("Monsters");
        Label treasure = new Label("Treasures");
        monster.getStyleClass().add("description");
        treasure.getStyleClass().add("description");

        ListView<String> monsters = new ListView<>();
        ListView<String> treasures = new ListView<>();
        monsters.getItems().addAll("Ant, giant", "Badger", "Beetle, fire", "Demon, manes", "Dwarf", "Ear Seeker", "Elf", "Gnome", "Goblin", "Hafling", "Hobgoblin", "Human Bandit", "Kobold", "Orc", "Piercer", "Rat, giant", "Shrieker", "Skeleton", "Zombie");
        treasures.getItems().addAll("1000 copper pieces/level", "1000 silver pieces/level", "750 electrum pieces/level", "250 gold pieces/level", "100 platinum pieces/level", "1-4 gems/level", "1 piece jewellery/level", "1 magic item");
        monsters.setMaxHeight(188);
        monsters.setMaxWidth(200);
        treasures.setMaxHeight(188);
        treasures.setMaxWidth(200);

        Button addMonster = new Button();
        addMonster.setText("Add Monster");
        addMonster.setOnAction(e -> {

            if (monsters.getSelectionModel().getSelectedItem() == null) {

                AlertBox.display("Error", "Select an item to add!");

            } else {

                String itemDescription = monsters.getSelectionModel().getSelectedItem();
                controller.addSpace(selection, itemDescription);
                description = "Changes Made to " + spaces.getSelectionModel().getSelectedItem();
                label.setText(description);
                addMenu.close();
                window.close();
                updateTable();

            }

        });

        Button addTreasure = new Button();
        addTreasure.setText("Add Treasure");
        addTreasure.setOnAction(e -> {

            if (treasures.getSelectionModel().getSelectedItem() == null) {

                AlertBox.display("Error", "Select an item to add!");

            } else {

                String itemDescription = treasures.getSelectionModel().getSelectedItem();
                controller.addSpace(selection, itemDescription);
                description = "Changes Made to " + spaces.getSelectionModel().getSelectedItem();
                label.setText(description);
                addMenu.close();
                window.close();
                updateTable();

            }

        });

        VBox left = new VBox();
        left.getChildren().addAll(monster, monsters, addMonster);
        left.setAlignment(Pos.CENTER);
        left.setSpacing(20);
        VBox right = new VBox();
        right.getChildren().addAll(treasure, treasures, addTreasure);
        right.setAlignment(Pos.CENTER);
        right.setSpacing(20);

        BorderPane layout = new BorderPane();
        layout.setLeft(left);
        layout.setRight(right);
        layout.setPadding(new Insets(20, 20, 20, 20));

        Scene editMenu = new Scene(layout, 500, 310);
        addMenu.setScene(editMenu);
        editMenu.getStylesheets().add("/res/theme.css");
        addMenu.showAndWait();

    }

}

/*
public class Main extends Application {

    static Stage window;
    static Scene menu, mainMenu;
    private static Random die = new Random();
    static Level level;
    static File file = new File("dungeons.txt");
    static Label label;
    static String description;
    static ArrayList<Chamber> chamberList;
    static HashMap<Door, ArrayList<Chamber>> map;
    static ArrayList<Door> doorList;
    static TreeView<String> tree;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

       window = primaryStage;
       window.setTitle("Main Menu");

       label = new Label("Dungeons and Dragons \n\t Level Viewer");
       label.setTranslateY(-50);

       Button button = new Button();
       button.setText("Generate Level");
       button.setTranslateX(-50);
       button.setTranslateY(0);
       button.setOnAction(e -> {
            level = new Level();
            window.close();
            levelMenu(0, 0);
       });

       Button button2 = new Button();
       button2.setText("Load Level");
       button2.setTranslateX(50);
       button2.setTranslateY(0);
       button2.setOnAction(e -> {

           loadLevel();

       });

       StackPane main = new StackPane();
       main.getChildren().addAll(button, button2, label);

       mainMenu = new Scene(main, 300, 250);

       window.setScene(mainMenu);
       window.show();

    }

    public static void levelMenu(int chamber, int door) {

        int width = 750;
        int height = 500;

        chamberList = level.getChamberList();
        HashMap<Door, ArrayList<Chamber>> map = level.getMap();

        Label leftLabel = new Label("Select a Chamber");
        leftLabel.setTranslateY(73);
        leftLabel.setTranslateX(10);

        MenuItem save = new MenuItem("Save");
        save.setOnAction(e -> {

             try {

                 ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file, true)));
                 out.writeObject(level);

             } catch (IOException u) {

             }

            window.close();
            window.show();

        });
        MenuItem load = new MenuItem("Load");
        load.setOnAction(e -> {

            loadLevel();

        });

        Menu fileMenu = new Menu("File");
        fileMenu.getItems().addAll(save, load);

        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().add(fileMenu);

        ComboBox<Integer> chamberDrop = new ComboBox<>();
        chamberDrop.setValue(chamberDrop.getValue());
        chamberDrop.getItems().addAll(1, 2, 3, 4, 5);
        chamberDrop.setTranslateY(75);
        chamberDrop.setTranslateX(10);
        chamberDrop.setValue(chamber);

        Label rightLabel = new Label("Select a Door");
        rightLabel.setTranslateY(73);
        rightLabel.setTranslateX(-10);

        Label desc = new Label(description);

        ListView<Integer> doorDrop = new ListView<>();
        doorDrop.setTranslateY(75);
        doorDrop.setTranslateX(-10);
        doorDrop.setMaxSize(100, 175);

        chamberDrop.setOnAction(e -> {

            doorDrop.getItems().clear();
            doorList = chamberList.get(chamberDrop.getValue() - 1).getDoors();

            for(int i = 0; i < doorList.size(); i++) {

                doorDrop.getItems().add(i + 1);

            }

        });

        Button button = new Button();
        button.setText("Description");
        button.setTranslateY(-10);
        button.setTranslateX(175);
        button.setOnAction(e -> {

            printDescription(chamberDrop, doorDrop);

        });

        Button button2 = new Button();
        button2.setText("Edit Level");
        button2.setTranslateY(-10);
        button2.setTranslateX(175);
        button2.setOnAction(e -> {

           editMenu(chamberDrop, doorDrop);

        });

        Button back = new Button();
        back.setText("Back");
        back.setTranslateY(-10);
        back.setTranslateX(175);
        back.setOnAction(e -> {

            window.close();
            window.setScene(mainMenu);
            window.show();

        });

        VBox leftLayout = new VBox();
        leftLayout.setSpacing(10);
        leftLayout.getChildren().addAll(leftLabel, chamberDrop);

        VBox rightLayout = new VBox();
        rightLayout.setSpacing(10);
        rightLayout.getChildren().addAll(rightLabel, doorDrop);

        HBox bottom = new HBox();
        bottom.setSpacing(20);
        bottom.getChildren().addAll(button, button2, back);

        BorderPane layout = new BorderPane();
        layout.setLeft(leftLayout);
        layout.setRight(rightLayout);
        layout.setBottom(bottom);
        layout.setCenter(desc);
        layout.setTop(menuBar);

        menu = new Scene(layout, width, height);
        window.setScene(menu);
        window.show();

    }

    public static void printDescription(ComboBox<Integer> chamberDrop, ListView<Integer> doorDrop) {

        if(chamberDrop.getValue() == null) {

            AlertBox.display("Error", "Please Select a Chamber");

        } else if(doorDrop.getSelectionModel().getSelectedItem() == null){

            AlertBox.display("Error", "Please Select a Door");

        } else {

            Chamber current = chamberList.get(chamberDrop.getValue() - 1);
            Door currentDoor = chamberList.get(chamberDrop.getValue() - 1).getDoors().get(doorDrop.getSelectionModel().getSelectedItem() - 1);

            description = "-----------------------Chamber-" + chamberDrop.getValue() + "---------------Door-" + doorDrop.getSelectionModel().getSelectedItem() + "------------------------------\n" + current.getDescription();

            for(int i = 0; i < chamberList.size(); i++) {

                if(currentDoor.getSpaces().get(1).equals(chamberList.get(i))) {

                    description += "\nLeads to Chamber: " + (i + 1);

                    for(int j = 0; j < chamberList.get(i).getDoors().size(); j++) {

                        if(chamberList.get(i).getDoors().get(j).getSpaces().get(1).equals(current)) {

                            description += "\tDoor: " + (j + 1);
                            break;

                        } else if (j + 1 == chamberList.get(i).getDoors().size()) {

                            description += "\tDoor: Any";
                            break;

                        }

                    }

                    break;

                }

            }

            description += currentDoor.getSpaces().get(2).getDescription();

            int door = doorDrop.getSelectionModel().getSelectedItem();

            levelMenu(0, door);

        }

    }

    public static void editMenu(ComboBox<Integer> chamberDrop, ListView<Integer> doorDrop) {

        TreeItem<String> root, add, remove;
        Stage window2 = new Stage();

        int height = 300;
        int width = 225;

        Button confirm = new Button();
        confirm.setText("Confirm");
        confirm.setTranslateX(85);
        confirm.setTranslateY(110);
        confirm.setOnAction(e -> {

            window2.close();
            editConfirm(chamberDrop, doorDrop);

        });

        root = new TreeItem<>();
        root.setExpanded(false);

        add = makeBranch("Add", root);
        makeBranch("Add Monster to passage", add);
        makeBranch("Add Treasure to passage", add);
        makeBranch("Add Monster to chamber", add);
        makeBranch("Add Treasure to chamber", add);

        remove = makeBranch("Remove", root);
        makeBranch("Remove Monster in passage", remove);
        makeBranch("Remove Treasure in passage", remove);
        makeBranch("Remove Monster in chamber", remove);
        makeBranch("Remove Treasure in chamber", remove);

        tree = new TreeView<>(root);
        tree.setShowRoot(false);

        //Layout
        GridPane layout = new GridPane();
        layout.getChildren().addAll(tree, confirm);
        Scene editMenu = new Scene(layout, width, height);
        window2.setScene(editMenu);
        window2.show();

    }

    public static TreeItem<String> makeBranch(String title, TreeItem<String> parent) {
        TreeItem<String> item = new TreeItem<>(title);
        item.setExpanded(true);
        parent.getChildren().add(item);
        return item;
    }

    public static void editConfirm(ComboBox<Integer> chamberDrop, ListView<Integer> doorDrop) {

        String test = String.valueOf(tree.getSelectionModel().getSelectedItem());

        if(test.contains("Add") && test.contains("chamber")) {

            if(test.contains("Monster")) {

                if(chamberList.get(chamberDrop.getValue() - 1).getMonsters() == null) {

                    AlertBox.display("Error", "This chamber already contains a monster!");

                } else {

                    Monster monster = new Monster();
                    chamberList.get(chamberDrop.getValue() - 1).addMonster(monster);

                }

            } else if(test.contains("Treasure")) {

                if(chamberList.get(chamberDrop.getValue() - 1).getTreasureList() == null) {

                    AlertBox.display("Error", "This chamber already contains a monster!");

                } else {

                    Treasure treasure = new Treasure();
                    chamberList.get(chamberDrop.getValue() - 1).addTreasure(treasure);

                }

            }

        } else if(test.contains("Remove") && test.contains("passage")) {

            if(test.contains("Monster")) {

                Monster monster = new Monster();
                Passage passage = ((Passage) chamberList.get(chamberDrop.getValue() - 1).getDoors().get(doorDrop.getSelectionModel().getSelectedItem() - 1).getSpaces().get(2));

                for(int i = 0; i < 2; i++) {

                    if(null == passage.getMonster(i)) {

                        passage.addMonster(monster, i);
                        break;

                    } else if (i + 1 == 2) {

                        AlertBox.display("Error", "This passage already has the maximum number of monsters!");

                    }

                }


            } else if(test.contains("Treasure")) {

                Treasure treasure = new Treasure();
                chamberList.get(chamberDrop.getValue() - 1).addTreasure(treasure);

            }

        }

    }

    public static void loadLevel() {

        ArrayList<Level> levels = new ArrayList<>();


        try {

            ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));

            while(true) {

                Object temp = in.readObject();
                if(temp instanceof Level) {

                    levels.add((Level) temp);

                }

            }


        } catch (IOException | ClassNotFoundException e) {

        }

        Stage window2 = new Stage();

        int height = 300;
        int width = 225;

        ListView<Integer> list = new ListView<>();
        list.setTranslateX(60);
        list.setTranslateY(5);
        for(int i = 0; i < levels.size(); i++) {

            list.getItems().add((i + 1));

        }
        list.setMaxSize(100, 175);

        Button confirm = new Button();
        confirm.setText("Confirm");
        confirm.setTranslateX(85);
        confirm.setTranslateY(110);
        confirm.setOnAction(e -> {

            if(list.getSelectionModel().getSelectedItem() != null) {

                level = levels.get(list.getSelectionModel().getSelectedItem() - 1);

                window2.close();
                window.close();
                levelMenu(0, 0);

            } else {

                AlertBox.display("Error", "Choose a level to load!");

            }

        });

        //Layout
        GridPane layout = new GridPane();
        layout.getChildren().addAll(list, confirm);
        Scene load = new Scene(layout, width, height);
        window2.setScene(load);
        window2.show();

    }

} */
