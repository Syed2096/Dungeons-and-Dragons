/*
*Name: Ahmed Syed
*Student ID: 105177
*/

/*Import Package*/
package dungeon;

/*Import Libraries*/
import java.util.Random;
import java.util.ArrayList;
import java.util.HashMap;

/**
*Generate level based on passages.
*/
public class Level implements java.io.Serializable {

    /**
    *Random number object.
    */
    private static Random die = new Random();

    /**
    *Random variable from random number object.
    */
    private static int random;

    /**
    *Chamber list variable.
    */
    private static ArrayList<Chamber> chamberList = new ArrayList<Chamber>();

    /**
    *Passages.
    */
    private static ArrayList<Passage> passageList = new ArrayList<>();

    /**
    *HashMap variable.
    */
    private static HashMap<Door, ArrayList<Chamber>> map = new HashMap<Door, ArrayList<Chamber>>();


    /**
    *Public constructor.
    */
    public Level() {

        map.clear();
        chamberList.clear();
        passageList.clear();
        this.generateLevel();

    }

    /**
    *Generting level method.
    */
    public static void generateLevel() {

        map = new HashMap<Door, ArrayList<Chamber>>();

        //Generate Chambers
        for (int i = 0; i < 5; i++) {

            Chamber chamber = new Chamber();

            chamberList.add(chamber);
            //System.out.println("\n--------------------------------------------------Chamber-" + (i + 1) + "--------------------------------------------------\n");
            //System.out.println(chamberList.get(i).getDescription());

        }

        //System.out.println();
        //System.out.println("-------------------------------------------------------LEVEL--------------------------------------------------------------------\n");


        //Loop through chambers
        for (int i = 0; i < 5; i++) {

            ArrayList<Door> chamberDoors = new ArrayList<Door>();
            chamberDoors = chamberList.get(i).getDoors();

            //Loop through chamber doors
            for (int j = 0; j < chamberDoors.size(); j++) {

                //If chamber is not assigned
                if (chamberDoors.get(j).getSpaces().size() < 2) {

                    do {

                        random = die.nextInt(5);

                    } while (random == i);

                    ArrayList<Door> targetDoors = new ArrayList<Door>();
                    targetDoors = chamberList.get(random).getDoors();

                    ArrayList<Chamber> target = new ArrayList<Chamber>();
                    target.add(chamberList.get(random));

                    ArrayList<Chamber> current = new ArrayList<Chamber>();
                    current.add(chamberList.get(i));

                    map.put(chamberDoors.get(j), target);

                    for (int k = 0; k < targetDoors.size(); k++) {

                        if (targetDoors.get(k).getSpaces().size() < 2) {

                            targetDoors.get(k).setSpace(chamberList.get(i));
                            chamberDoors.get(j).setSpace(chamberList.get(random));

                            map.put(targetDoors.get(k), current);

                            //System.out.println("----------------------------------------------------------------------------------\nChamber: " + (i + 1) + "\tDoor: " + (j + 1) + "\t\tLeads to Chamber: " + (random + 1) + "\tDoor: " + (k + 1));

                            //Create passage and print description
                            Passage passage = generatePassage();
                            passage.setDoor(chamberDoors.get(j));
                            passage.setDoor(targetDoors.get(k));
                            passageList.add(passage);
                            targetDoors.get(k).setSpace(passage);
                            chamberDoors.get(j).setSpace(passage);

                            //System.out.println("\nPassage: " + passage.getDescription() + "----------------------------------------------------------------------------------");

                            break;


                        } else if (k + 1 == targetDoors.size()) {

                            do {

                                k = die.nextInt(targetDoors.size());

                            } while (k == j);

                            targetDoors.get(k).setSpace(chamberList.get(i));
                            chamberDoors.get(j).setSpace(chamberList.get(random));

                            map.put(targetDoors.get(k), current);

                            //System.out.println("----------------------------------------------------------------------------------\nChamber: " + (i + 1) + "\tDoor: " + (j + 1) + "\t\tLeads to Chamber: " + (random + 1) + "\tDoor: " + (k + 1));

                            //Create passage and print description
                            Passage passage = generatePassage();
                            passage.setDoor(chamberDoors.get(j));
                            passage.setDoor(targetDoors.get(k));
                            passageList.add(passage);
                            targetDoors.get(k).setSpace(passage);
                            chamberDoors.get(j).setSpace(passage);

                            //System.out.println("\nPassage: " + passage.getDescription() + "----------------------------------------------------------------------------------");

                            break;

                        }

                    }

                }
            }

        }

    }

    private static Passage generatePassage() {

        Passage passage = new Passage();

        random = die.nextInt(20) + 1;

        if (random <= 2) {

            PassageSection section = new PassageSection("passage goes straight for 10 ft");

            passage.addPassageSection(section);

        } else if (random <= 7) {

            PassageSection section = new PassageSection("archway (door) to right (main passage continues straight for 10 ft)");

            section.getDoor().setArchway(true);

            passage.addPassageSection(section);

        } else if (random <= 9) {

            PassageSection section = new PassageSection("archway (door) to left (main passage continues straight for 10 ft)");

            section.getDoor().setArchway(true);

            passage.addPassageSection(section);

        } else if (random <= 11) {

            PassageSection section = new PassageSection("passage turns to left and continues for 10 ft");

            section.getDoor().setIsDoor(false);

            passage.addPassageSection(section);

        } else if (random <= 13) {

            PassageSection section = new PassageSection("passage turns to right and continues for 10 ft");

            section.getDoor().setIsDoor(false);

            passage.addPassageSection(section);

        } else if (random == 17) {

            PassageSection section = new PassageSection("Stairs, (passage continues straight for 10 ft)");

            passage.addPassageSection(section);

        } else {

            PassageSection section = new PassageSection("Wandering Monster (passage continues straight for 10 ft)");

            passage.addPassageSection(section);

        }

        random = die.nextInt(2) + 1;

        if (random == 1) {

            PassageSection section = new PassageSection("passage ends in Door to a Chamber");

            passage.addPassageSection(section);

        } else {

            PassageSection section = new PassageSection("passage ends in archway (door) to chamber");

            passage.addPassageSection(section);

        }


        //passage section to chamber. add section.

        return passage;

    }

    /**
     * Gets chamberList.
     * @return chamberList
     */
    public static ArrayList<Chamber> getChamberList() {
        return chamberList;
    }

    /**
     * Gets map.
     * @return map
     */
    public static  HashMap<Door, ArrayList<Chamber>> getMap() {
        return map;
    }

    /**
     * Gets passageList.
     * @return passageList
     */
    public static ArrayList<Passage> getPassageList() {
        return passageList;
    }

}
