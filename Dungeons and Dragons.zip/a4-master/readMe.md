Name: Ahmed Syed
Student ID: 1051777
Email: asyed12@uoguelph.ca

Statement: I did this assignment on my own.

Mark css stylesheet and (chamber and passage view) visual generator.
Also my loading does not work and I would appreciate it if someone could 
explain why in my feedback.
